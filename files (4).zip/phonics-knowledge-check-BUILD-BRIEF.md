# Build Brief — Phonics Knowledge Check (Literacy Arcade)

**Deliverable:** `phonics-knowledge-check.html` — one self-contained single-file HTML tool (inline CSS + JS, base64 assets), same architecture as `letter-sound-knowledge-check.html`.

**Approach:** Do **not** build from scratch. Copy `letter-sound-knowledge-check.html` (the latest version in the repo) and adapt it. Reuse its entire design system, `<head>`, brand/logo base64, topbar, card scaffold, popover shell, optional-timer, print system, proficiency-band CSS, and the static-footer fix. Replace only the body panels, the setup controls, the popover behavior, and the `<script>`. Two ready-made drop-ins are provided alongside this brief:

- `phonics_script.js` — the **complete** engine (word data + scoring + analysis + render + print + wiring). Already syntax-validated with `node --check`. Drop it in as the single `<script>` block (it already includes the `<script>…</script>` wrapper).
- The CSS block in **§7** below — append before `</style>`.

---

## 1. Non-negotiable conventions (from the master rules)

- Single-file HTML; inline CSS/JS; assets base64-inlined. Works on `file://` and GitHub Pages.
- Brand: Cream `#FAF8F4`, Navy `#1B2D45`, Teal `#2EC4B6`, Coral `#FF6B6B`, violet accent. Fonts: **Nunito** (teacher UI), **Lexend** (all student-facing letters/words).
- LA logo (`.brand-mark`) in the topbar **and** in every print header. Pull the print logo at runtime via `document.querySelector('.brand-mark').src` (already done in `phonics_script.js`).
- **Never** use `!important` except the two already-documented exceptions. Edit at the source selector; never patch-stack override blocks.
- Validate JS with `node --check` before delivering. Use Python + Playwright for headless render/verification.
- Exact filename is locked: `phonics-knowledge-check.html`. Tool name: **Phonics Knowledge Check**.
- Language stays **instructional, never diagnostic/medical**. Hedge with "possible focus." Do not reproduce CORE wording or word lists — this uses Chelsea's own words and reworded prompts.

## 2. Print fixes to carry over (already handled in `phonics_script.js` + §7)

- **Static report footer:** the report footer must flow at the end of content, not be `position:fixed` (which overlaps page 1). Scope it: `.print-report .print-footer{position:static;…;margin-top:20px;break-inside:avoid}` and `.print-report{padding-bottom:.18in}`. The student sheet keeps its fixed footer (always one page).
- **Student-sheet logo gap:** ensure `.print-student .print-brand-left{gap:10px}` (an old rule set it to `gap:0`).
- **Safari logo:** print uses `img.decode().then(window.print)` (already in `printContent`).
- `[hidden]{display:none}` is needed so hidden flex/grid chips actually hide.

## 3. The v1 spec (Chelsea's decisions — authoritative)

- **Sections (7), administration order = easy→hard.** Teacher toggles choose which to administer (default all on). A disabled "Multisyllabic words — coming later" placeholder sits at the bottom of the toggle list. Sections: Short Vowels in CVC Words · Consonant Blends with Short Vowels · Short Vowels with Digraphs/Trigraphs · R-Controlled Vowels · Long Vowel Spellings · Variant Vowels · Low-Frequency Vowel & Consonant Spellings. **Multisyllabic is paused** (not built).
- **5 words/section v1** (3 real + 2 nonsense). CVC section = one word per short vowel a/e/i/o/u. Data structure must support the future 15-word plan (10 real + 5 nonsense). Full starter data is embedded in `phonics_script.js` as `PHONICS_WORDS` and is easy to edit (fields: `word`, `type` `'real'|'nonsense'`, `targetPattern`, `targetVowel`, `notes`).
- **Student-facing words:** lowercase, Lexend. Teacher view may show a small real/nonsense tag; the **student sheet stays clean** (no tags).
- **Interaction:** whole section visible at once. Default unmarked = correct. Tap a word → mark wrong → a **required** panel: type what the student said **or** click "Skipped / did not know." Dismissing the panel without either (Esc / click-outside / Cancel) **reverts the word to correct**. The typed response is **not optional** when wrong.
- **Bands:** **Strong control ≥ 85% · Developing 60–84% · Needs support < 60%**, per section and overall. Always show the raw score (e.g. `4/5`). Framed as instructional guidance, not a normed benchmark.
- **Report shows:** total accuracy; accuracy by section (with band + real/nonsense split); real-vs-nonsense overall; misread-word list; error patterns grouped with plain-language "possible instructional focus" guidance; teacher notes; a printable student word sheet and a printable teacher report.
- **No discontinue rule** — teacher administers any sections freely. The report may include a gentle "consider stopping/shortening if a section was clearly too hard" note, but nothing auto-skips or locks.

## 4. Analysis engine (conservative v1 — already implemented in `analyzeError`)

Per misread word, comparing target vs. typed response:

- **skipped** → its own category (no response to analyze).
- **digraph/trigraph confusion** → target's pattern is a digraph/trigraph and the error drops/changes it (`ship→sip`, `catch→cat`).
- **blend reduction** → initial 2-consonant cluster with one consonant dropped (`stop→top`).
- **final sound deletion** → response is the target minus its final 1–2 letters (`cat→ca`).
- **vowel / pattern substitution** → consonant frame preserved (vowels stripped, skeletons equal) but the vowel changed (`dog→dig`) → focus = `targetVowel` (works for r-controlled/long/vowel-team too: `farm→form` → "r-controlled ar /ar/").
- **consonant change** → consonant frame differs, basic sections (`cat→bat`) → counted wrong, **no vowel claim**.
- **target pattern missed** → consonant frame differs in an **advanced** section (r-controlled, long, variant, low-frequency) → conservative "possible focus: <targetPattern>."
- **possible real-word substitution** → secondary tag added when a **nonsense** item is misread (soft "possible lexicalization," no dictionary, no certainty).

Report wording is tentative ("possible instructional focus") throughout. A word can appear under more than one note.

## 5. Structural adaptation map (what to replace in the copied file)

Replace these blocks; **keep everything else** (head/CSS/topbar/print scaffold/logo). The element IDs below are what `phonics_script.js` expects — they must match exactly.

| Block (by id/anchor) | Replace with |
|---|---|
| `<head>` meta/title/SEO/JSON-LD | Phonics text; canonical/og/twitter url → `phonics-knowledge-check.html` |
| topbar `.tool-title` | `Phonics Knowledge Check` |
| `#overviewPanel` | Phonics intro + "How it works" + "What this check shows" |
| `#gridPanel` | Admin cue (`#adminCue`), `<div id="sectionsHost">`, `#errorCounter`, live summary host `#liveSectionPills` + `#liveMissed` |
| `#resultsPanel` | Overall banner (`#obScore`,`#obBand`,`#obSub`) + `#sectionResults` + `#realNonsenseMetrics` + `#missedWords` + `#patternNotes` + `#teacherNotes`/`#clearNotesBtn` |
| `#setupControls` | Keep name/date/grade/time; phonics mode card; `<div id="sectionToggleHost">`; **remove Form radios**; keep timer toggle `#optTimer` |
| `#activeControls` | Chips `#wordsChip` / `#errorsChip` / `#skippedChip` / `#accChip`; keep timer card (`#timerCard`, `#startTimerBtn`, `#stopTimerBtn`, `#resetTimerBtn`, `#timerDisplay`, `#timerHint`, `#timeUpBanner`); `#finishedSheetBtn` / `#backSetupBtn`; `#workflowBanner` |
| `#completeControls` | `#cWords` + `#completeDetails` + `#accuracyComplete` / `#errorsComplete` / `#timeChipComplete`+`#fullTimeComplete`; `#printReportBtn` / `#editScoringCompleteBtn` / `#newAssessmentBtn` |
| `.footer` text | `Literacy Arcade • Phonics Knowledge Check` |
| `#responsePopover` | `#responseTitle`, `#responsePrompt`, `#responseInput`, `#quickResponseButtons` containing one button `data-response="__SKIP__"` labeled "Skipped / did not know", `#skipResponseBtn` (now = **Cancel**), `#saveResponseBtn` (disabled until text) |
| `<script>…</script>` | the entire contents of `phonics_script.js` |

## 6. Suggested body HTML for the replaced panels

Use the existing classes from the Letter Sound file (`eyebrow`, `headline`, `subhead`, `ready-box overview-ready`, `overview-grid`, `overview-card`, `check-points`, `grid-head`, `details.admin`/`admin-body`/`say`, `counter`, `live-under-grid`/`live-summary-row`/`live-pill`/`lp-l`, `missed-preview`, `results-head`/`eyebrow`/`results-meta`, `result-grid simple-results`, `results-card`/`full-span`/`teacher-notes-card`, `metric-list`, `miss-list`, `pattern-note`/`pattern-intro`, `student-details-grid`/`field`/`field full`, `setup-mode-card`, `opt-toggle`/`opt-track`/`opt-text`, `setup-actions`, `workflow-banner`, `timer-card` & children, `status-grid`/`score-chip`, `action-grid`, `complete-detail-line`, `band-pill`). New phonics-specific classes are styled in §7. Match the IDs in the table above. (The assistant can generate these panels verbatim on request, but any markup that preserves those IDs and classes will work.)

Overview "What this check shows" points: Decoding by pattern · Real vs nonsense words · Accuracy by section · Instructional focus.

Admin cue (reworded, not CORE): "Read these words for me." / "These are made-up words — sound them out, they aren't real words." / mark only misreads, then type what they said / too-hard words can be marked Skipped.

Popover: title `Marked wrong: <word>`, prompt "Type what the student read, or mark skipped.", one quick button "Skipped / did not know" (`data-response="__SKIP__"`), Cancel + Save (Save disabled until input has text).

## 7. CSS to append before `</style>`

```css
/* ===== Phonics Knowledge Check additions ===== */
.phonics-section{margin:16px 0 0}
.phonics-section .sec-h{font-size:1rem;font-weight:900;margin:0 0 2px;color:var(--ink);display:flex;justify-content:space-between;align-items:baseline;gap:10px}
.phonics-section .sec-h .sec-score{font-weight:900;font-size:.82rem;color:var(--teal-dark)}
.phonics-section .sec-sub{color:#8f8a9f;font-weight:800;font-size:.74rem;margin:0 0 8px}
.word-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.word-tile{position:relative;border:1.5px solid #cfe0ec;background:#fff;border-radius:12px;padding:13px 8px 16px;min-height:62px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;cursor:pointer;transition:.12s;box-shadow:var(--shadow-soft)}
.word-tile:hover{border-color:var(--teal)}
.word-tile .wt-word{font-family:Lexend,Arial,sans-serif;font-size:1.2rem;font-weight:700;color:#19324a;line-height:1}
.word-tile .wt-tag{font-weight:900;font-size:.54rem;letter-spacing:.05em;text-transform:uppercase;color:#a7a3b5}
.word-tile .wt-tag.nonsense{color:#b07d2a}
.word-tile.incorrect{border-color:var(--coral);background:var(--coral-pale)}
.word-tile.incorrect .wt-word{color:#8e2525}
.word-tile.skipped{border-style:dashed}
.word-tile .wt-resp{position:absolute;left:5px;right:5px;bottom:3px;font-size:.6rem;font-weight:800;color:#9b2c2c;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}
@media(max-width:760px){.word-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:430px){.word-grid{grid-template-columns:repeat(2,1fr)}}
.section-toggle-host{display:grid;gap:7px}
.sec-toggle{display:flex;align-items:center;gap:10px;border:1px solid var(--line);border-radius:11px;padding:9px 11px;background:#fff;cursor:pointer;text-transform:none;letter-spacing:normal;font-weight:400}
.sec-toggle input{position:absolute;opacity:0;width:1px;height:1px}
.sec-toggle .st-textwrap{display:grid;gap:1px}
.sec-toggle .st-text{font-weight:800;font-size:.86rem;color:#3d3a5f}
.sec-toggle .st-sub{font-weight:700;font-size:.72rem;color:#9a96ad}
.sec-toggle.disabled{opacity:.55;cursor:not-allowed}
.sec-result-row{display:grid;grid-template-columns:1fr auto auto;align-items:center;gap:14px;padding:11px 0;border-bottom:1px solid var(--line)}
.sec-result-row:last-child{border-bottom:none}
.sec-result-row .srr-name{font-weight:900;color:var(--ink);font-size:.92rem}
.sec-result-row .srr-name small{display:block;font-weight:800;color:#9a96ad;font-size:.72rem;margin-top:1px}
.sec-result-row .srr-score{font-weight:900;font-size:1.1rem;color:var(--teal-dark);text-align:right}
.sec-result-row .srr-score small{color:#9a96ad;font-weight:800;font-size:.8rem}
.overall-banner{display:grid;grid-template-columns:auto 1fr;align-items:center;gap:18px;border:1px solid var(--line);border-left:8px solid var(--teal);border-radius:16px;background:#fff;padding:16px 18px;box-shadow:var(--shadow-soft);margin-bottom:14px}
.overall-banner .ob-score{display:flex;align-items:center;gap:12px}
.overall-banner .ob-score>span{font-size:2.2rem;font-weight:900;color:var(--teal-dark);letter-spacing:-.04em;line-height:1;white-space:nowrap}
.overall-banner .ob-meta p{margin:0;font-weight:900;font-size:1rem;color:var(--ink)}
.overall-banner .ob-meta small{color:#67706f;font-weight:800;font-size:.82rem}
@media(max-width:650px){.overall-banner{grid-template-columns:1fr}}
@media print{
  .ps-section{margin:0 0 14px;break-inside:avoid}
  .ps-section h2{font-size:12.5pt;margin:0 0 6px;color:#17162e}
  .ps-words{display:flex;flex-wrap:wrap;gap:10px 18px}
  .ps-word{font-family:Lexend,Arial,sans-serif;font-size:15pt;font-weight:700;color:#19324a}
  .print-section-table th{text-align:left;font-size:8.5pt;color:#6f6b86;border-bottom:1px solid #d8ecea;padding:3px 6px}
  .print-section-table td{padding:3px 6px;border-bottom:1px solid #eef3f6}
}
```
> Note: `band-pill` / `.band-bench` / `.band-dev` / `.band-need` already exist in the Letter Sound file and are reused (green = Strong control, amber = Developing, coral = Needs support).

## 8. Remaining build steps

1. Copy `letter-sound-knowledge-check.html` → `phonics-knowledge-check.html`.
2. Swap the head meta/title/SEO/JSON-LD and the topbar tool-title to Phonics.
3. Replace the body panels + setup + controls + popover + footer per §5/§6.
4. Append the §7 CSS before `</style>`.
5. Replace the `<script>` block with the contents of `phonics_script.js`.
6. Verify (see §9). Then it's ready to commit / deploy to GitHub Pages.

## 9. Verification checklist (Playwright + node)

- `node --check` on the extracted `<script>`.
- Setup: all 7 section toggles render + the disabled Multisyllabic placeholder; toggling sections off excludes them.
- Scoring: each administered section shows 5 word tiles (lowercase, real/nonsense tag); tap marks wrong and opens the required panel.
- Required-response: typing + Save keeps it wrong with the response; "Skipped / did not know" marks skipped; Cancel / Esc / click-outside **reverts to correct**; Save stays disabled until text is entered.
- Analysis fires correctly: `dog→dig` (vowel sub → short o /ŏ/), `cat→bat` (consonant change, no vowel claim), `stop→top` (blend reduction), `ship→sip` (digraph), `cat→ca` (final deletion), a skipped item, a nonsense item misread (possible lexicalization), an advanced-section frame change (target pattern missed).
- Bands: 85/60 thresholds per section + overall; raw score shown.
- Real vs nonsense split correct overall and per section.
- Print: student sheet (logo + clean lowercase words, no tags) and report (logo, overall + band, section table, real/nonsense, pattern notes, teacher notes, closing note) — render the report to a 2-page PDF and confirm the footer flows (no overlap).

## 10. Future (not in v1)

15 words/section (10 real + 5 nonsense); the Multisyllabic section; a separate **Heart Word Knowledge Check** for high-frequency irregular words (explicitly excluded here); optional MP3 audio is unrelated to this tool.
