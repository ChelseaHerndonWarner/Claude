  <script>
  (() => {
    const $ = id => document.getElementById(id);

    /* ============================ WORD DATA ============================ */
    /* Easy to edit: add/remove words or sections. Each word supports:
       word · type ('real'|'nonsense') · targetPattern · targetVowel · notes.
       Words are listed easy → hard within a section. To expand to 15 words,
       add more entries (plan: 10 real + 5 nonsense per section). */
    const PHONICS_WORDS = [
      { sectionId:"short-vowels-cvc", sectionTitle:"Short Vowels in CVC Words", words:[
        { word:"cat", type:"real",     targetPattern:"CVC short vowel", targetVowel:"short a /ă/", notes:"short a in a simple CVC word" },
        { word:"bed", type:"real",     targetPattern:"CVC short vowel", targetVowel:"short e /ĕ/", notes:"short e in a simple CVC word" },
        { word:"pig", type:"real",     targetPattern:"CVC short vowel", targetVowel:"short i /ĭ/", notes:"short i in a simple CVC word" },
        { word:"zop", type:"nonsense", targetPattern:"CVC short vowel", targetVowel:"short o /ŏ/", notes:"nonsense; short o CVC" },
        { word:"mub", type:"nonsense", targetPattern:"CVC short vowel", targetVowel:"short u /ŭ/", notes:"nonsense; short u CVC" }
      ]},
      { sectionId:"blends-short-vowels", sectionTitle:"Consonant Blends with Short Vowels", words:[
        { word:"stop", type:"real",     targetPattern:"initial consonant blend with short vowel", targetVowel:"short o /ŏ/", notes:"initial s-blend; short o" },
        { word:"clap", type:"real",     targetPattern:"initial consonant blend with short vowel", targetVowel:"short a /ă/", notes:"initial l-blend; short a" },
        { word:"desk", type:"real",     targetPattern:"final consonant blend with short vowel",   targetVowel:"short e /ĕ/", notes:"final blend; short e" },
        { word:"glip", type:"nonsense", targetPattern:"initial consonant blend with short vowel", targetVowel:"short i /ĭ/", notes:"nonsense; l-blend; short i" },
        { word:"brum", type:"nonsense", targetPattern:"initial consonant blend with short vowel", targetVowel:"short u /ŭ/", notes:"nonsense; r-blend; short u" }
      ]},
      { sectionId:"digraphs-trigraphs-short-vowels", sectionTitle:"Short Vowels with Digraphs and Trigraphs", words:[
        { word:"ship",  type:"real",     targetPattern:"consonant digraph sh with short vowel", targetVowel:"short i /ĭ/", notes:"initial sh; short i" },
        { word:"chop",  type:"real",     targetPattern:"consonant digraph ch with short vowel", targetVowel:"short o /ŏ/", notes:"initial ch; short o" },
        { word:"catch", type:"real",     targetPattern:"-tch trigraph with short vowel",        targetVowel:"short a /ă/", notes:"-tch trigraph; short a" },
        { word:"thep",  type:"nonsense", targetPattern:"consonant digraph th with short vowel", targetVowel:"short e /ĕ/", notes:"nonsense; th; short e" },
        { word:"shub",  type:"nonsense", targetPattern:"consonant digraph sh with short vowel", targetVowel:"short u /ŭ/", notes:"nonsense; sh; short u" }
      ]},
      { sectionId:"r-controlled-vowels", sectionTitle:"R-Controlled Vowels", words:[
        { word:"farm", type:"real",     targetPattern:"r-controlled ar", targetVowel:"r-controlled ar /ar/", notes:"r-controlled ar" },
        { word:"herd", type:"real",     targetPattern:"r-controlled er", targetVowel:"r-controlled er /ər/", notes:"r-controlled er" },
        { word:"bird", type:"real",     targetPattern:"r-controlled ir", targetVowel:"r-controlled ir /ər/", notes:"r-controlled ir" },
        { word:"dorn", type:"nonsense", targetPattern:"r-controlled or", targetVowel:"r-controlled or /or/", notes:"nonsense; r-controlled or" },
        { word:"murf", type:"nonsense", targetPattern:"r-controlled ur", targetVowel:"r-controlled ur /ər/", notes:"nonsense; r-controlled ur" }
      ]},
      { sectionId:"long-vowel-spellings", sectionTitle:"Long Vowel Spellings", words:[
        { word:"cake", type:"real",     targetPattern:"long a silent e",        targetVowel:"long a /ā/", notes:"CVCe long a" },
        { word:"feet", type:"real",     targetPattern:"long e vowel team ee",   targetVowel:"long e /ē/", notes:"ee vowel team" },
        { word:"bike", type:"real",     targetPattern:"long i silent e",        targetVowel:"long i /ī/", notes:"CVCe long i" },
        { word:"soam", type:"nonsense", targetPattern:"long o vowel team oa",   targetVowel:"long o /ō/", notes:"nonsense; oa vowel team" },
        { word:"fute", type:"nonsense", targetPattern:"long u silent e",        targetVowel:"long u /ū/", notes:"nonsense; CVCe long u" }
      ]},
      { sectionId:"variant-vowels", sectionTitle:"Variant Vowels", words:[
        { word:"coin",  type:"real",     targetPattern:"oi vowel team", targetVowel:"oi /oi/", notes:"variant vowel oi" },
        { word:"shout", type:"real",     targetPattern:"ou vowel team", targetVowel:"ou /ow/", notes:"variant vowel ou" },
        { word:"moon",  type:"real",     targetPattern:"oo vowel team", targetVowel:"oo /ū/", notes:"oo as in moon" },
        { word:"zoy",   type:"nonsense", targetPattern:"oy vowel team", targetVowel:"oy /oi/", notes:"nonsense; variant vowel oy" },
        { word:"vawp",  type:"nonsense", targetPattern:"aw vowel team", targetVowel:"aw /ô/", notes:"nonsense; variant vowel aw" }
      ]},
      { sectionId:"low-frequency-spellings", sectionTitle:"Low-Frequency Vowel and Consonant Spellings", words:[
        { word:"phone", type:"real",     targetPattern:"ph spelling for /f/",       targetVowel:"long o /ō/",  notes:"low-frequency ph" },
        { word:"cent",  type:"real",     targetPattern:"soft c spelling for /s/",   targetVowel:"short e /ĕ/", notes:"soft c before e" },
        { word:"lamb",  type:"real",     targetPattern:"final mb with silent b",    targetVowel:"short a /ă/", notes:"silent b in mb" },
        { word:"gnip",  type:"nonsense", targetPattern:"gn spelling with silent g", targetVowel:"short i /ĭ/", notes:"nonsense; silent g" },
        { word:"wrel",  type:"nonsense", targetPattern:"wr spelling with silent w", targetVowel:"short e /ĕ/", notes:"nonsense; silent w" }
      ]}
      // Multisyllabic words — planned for a later version.
    ];
    const ADVANCED = new Set(["r-controlled-vowels","long-vowel-spellings","variant-vowels","low-frequency-spellings"]);

    // Flatten with stable ids.
    PHONICS_WORDS.forEach(sec => sec.words.forEach((w,i) => { w.id = `${sec.sectionId}:${i}`; w.sectionId = sec.sectionId; w.sectionTitle = sec.sectionTitle; }));
    const ALL_WORDS = PHONICS_WORDS.flatMap(s => s.words);
    const WORD_BY_ID = Object.fromEntries(ALL_WORDS.map(w => [w.id, w]));

    /* ============================ ANALYSIS ============================ */
    const VOWELS = new Set(['a','e','i','o','u']);
    const DIGRAPHS = ['tch','sh','ch','th','wh','ph','ck','ng','qu'];
    const consFrame = w => w.toLowerCase().replace(/[aeiou]/g,'');
    function detectDigraph(target){ for(const d of DIGRAPHS){ if(target.includes(d)) return d; } return null; }

    // Returns array of primary tag keys (+ optional 'lexicalization').
    function analyzeError(item, response, skipped){
      if(skipped) return ['skipped'];
      const target = item.word.toLowerCase();
      const r = String(response||'').toLowerCase().replace(/[^a-z]/g,'');
      if(!r || r === target) return ['other'];
      const tags = [];
      let primary = null;
      const isDigraphTarget = /digraph|trigraph/.test(item.targetPattern||'');
      if(isDigraphTarget){
        const d = detectDigraph(target);
        if(d && !r.includes(d)) primary = 'digraph';
      }
      if(!primary && target.startsWith(r) && (target.length - r.length) >= 1 && (target.length - r.length) <= 2 && r.length >= 2){
        primary = 'final_deletion';
      }
      if(!primary){
        const isC = ch => ch && !VOWELS.has(ch);
        if(isC(target[0]) && isC(target[1]) && (r === target.slice(1) || r === target[0] + target.slice(2))){
          primary = 'blend_reduction';
        }
      }
      if(!primary){
        primary = (consFrame(target) === consFrame(r)) ? 'vowel_substitution' : 'consonant_change';
        if(primary === 'consonant_change' && ADVANCED.has(item.sectionId)) primary = 'pattern_missed';
      }
      tags.push(primary);
      if(item.type === 'nonsense') tags.push('lexicalization');
      return tags;
    }
    function focusFor(item, tag){
      if(tag === 'vowel_substitution') return item.targetVowel || item.targetPattern;
      if(tag === 'digraph'){ const d = detectDigraph(item.word.toLowerCase()); return d ? `the ${d} ${d.length===3?'trigraph':'digraph'}` : item.targetPattern; }
      if(tag === 'pattern_missed') return item.targetPattern;
      return null;
    }
    const PAT = {
      vowel_substitution:{ label:'Vowel / pattern substitution', order:1,
        guide:'The consonants were kept but the vowel changed (for example, dog → dig). Each example notes a possible vowel or pattern focus.' },
      digraph:{ label:'Digraph / trigraph confusion', order:2,
        guide:'A digraph or trigraph may not be secure yet (for example, ship → sip). Possible instructional focus: the noted sound-spelling.' },
      blend_reduction:{ label:'Blend reduction', order:3,
        guide:'Part of a consonant blend was dropped (for example, stop → top). Possible instructional focus: blending every sound in initial blends.' },
      final_deletion:{ label:'Final sound deletion', order:4,
        guide:'The ending sound was dropped (for example, cat → ca). Possible instructional focus: reading all the way through the word.' },
      consonant_change:{ label:'Consonant change', order:5,
        guide:'A consonant was read differently, so the word changed (for example, cat → bat). Counted wrong; the vowel was not clearly the issue here.' },
      pattern_missed:{ label:'Target pattern missed', order:6,
        guide:'The word changed in a way that points away from the target pattern. Possible instructional focus: the noted pattern.' },
      lexicalization:{ label:'Possible real-word substitution', order:7,
        guide:'On a made-up word, the student may have read a familiar real word instead of decoding it. Possible instructional focus: sounding through unfamiliar words rather than guessing.' },
      skipped:{ label:'Skipped / no attempt', order:8,
        guide:'No spoken response to analyze. Revisit these words later to see whether the student can attempt them with support.' },
      other:{ label:'Misread', order:9,
        guide:'Counted wrong. Not enough information to point to a specific pattern.' }
    };

    /* ============================ HELPERS ============================ */
    const esc = v => String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
    const formatDate = val => val ? new Date(val+'T12:00:00').toLocaleDateString(undefined,{year:'numeric',month:'long',day:'numeric'}) : '—';
    const mmss = total => { const s=Math.max(0,Math.floor(total||0)); return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; };
    const studentName = () => $('studentName').value.trim() || 'Unnamed student';
    const gradeText = (fb='Not selected') => $('gradeLevel')?.value || fb;
    const yearText = (fb='Not selected') => $('timeOfYear')?.value || fb;
    const pct = (c,t) => t ? Math.round(c/t*100) : 0;
    // Strong control >=85% · Developing 60-84% · Needs support <60%
    function bandFor(c,t){ const p = t ? c/t : 0; if(p>=0.85) return ['Strong control','band-bench','strong']; if(p>=0.60) return ['Developing','band-dev','dev']; return ['Needs support','band-need','need']; }
    function pbandHtml(c,t){ const [lab,,k]=bandFor(c,t); return `<span class="pband ${k}">${lab}</span>`; }
    const metric = (label,value) => `<div class="metric"><span>${label}</span><b>${value}</b></div>`;

    /* ============================ STATE ============================ */
    const state = {
      sections: PHONICS_WORDS.map(s => s.sectionId), // administered (set in setup)
      adminSecs: [],
      timer:false,
      marks:{}, // id -> {wrong:true, response, skipped, pending}
      elapsed:0, running:false, completed:false, startAt:null, raf:null,
      activeId:null
    };
    $('assessmentDate').value = new Date().toISOString().slice(0,10);

    /* ============================ SETUP ============================ */
    function renderSectionToggles(){
      const host = $('sectionToggleHost'); host.innerHTML='';
      PHONICS_WORDS.forEach(sec => {
        const real = sec.words.filter(w=>w.type==='real').length;
        const non = sec.words.filter(w=>w.type==='nonsense').length;
        const lab = document.createElement('label');
        lab.className='sec-toggle';
        lab.innerHTML = `<input type="checkbox" class="sec-check" value="${sec.sectionId}" checked><span class="opt-track"></span><span class="st-textwrap"><span class="st-text">${esc(sec.sectionTitle)}</span><span class="st-sub">${sec.words.length} words · ${real} real, ${non} nonsense</span></span>`;
        host.appendChild(lab);
      });
      const ph = document.createElement('label');
      ph.className='sec-toggle disabled';
      ph.innerHTML = `<input type="checkbox" disabled><span class="opt-track"></span><span class="st-textwrap"><span class="st-text">Multisyllabic words</span><span class="st-sub">Coming in a later version</span></span>`;
      host.appendChild(ph);
    }

    function collectSetup(){
      const checked = [...document.querySelectorAll('.sec-check:checked')].map(c=>c.value);
      state.sections = checked.length ? checked : PHONICS_WORDS.map(s=>s.sectionId);
      state.adminSecs = PHONICS_WORDS.filter(s => state.sections.includes(s.sectionId));
      state.timer = $('optTimer').checked;
      state.marks = {};
    }

    /* ============================ SCORING ============================ */
    function scoreData(){
      const sections = state.adminSecs.map(sec => {
        const words = sec.words;
        const wrongIds = words.filter(w => state.marks[w.id]?.wrong).map(w=>w.id);
        const correct = words.length - wrongIds.length;
        const real = words.filter(w=>w.type==='real');
        const non = words.filter(w=>w.type==='nonsense');
        const realCorrect = real.filter(w=>!state.marks[w.id]?.wrong).length;
        const nonCorrect = non.filter(w=>!state.marks[w.id]?.wrong).length;
        return { id:sec.sectionId, title:sec.sectionTitle, total:words.length, correct,
                 realTotal:real.length, realCorrect, nonTotal:non.length, nonCorrect, wrongIds };
      });
      const total = sections.reduce((a,s)=>a+s.total,0);
      const correct = sections.reduce((a,s)=>a+s.correct,0);
      const realTotal = sections.reduce((a,s)=>a+s.realTotal,0);
      const realCorrect = sections.reduce((a,s)=>a+s.realCorrect,0);
      const nonTotal = sections.reduce((a,s)=>a+s.nonTotal,0);
      const nonCorrect = sections.reduce((a,s)=>a+s.nonCorrect,0);
      // error details
      const details = [];
      state.adminSecs.forEach(sec => sec.words.forEach(w => {
        const m = state.marks[w.id];
        if(m?.wrong){
          const tags = analyzeError(w, m.response, m.skipped);
          details.push({ word:w.word, response:m.skipped ? '(skipped)' : (m.response||''), skipped:!!m.skipped,
                         type:w.type, section:w.sectionTitle, item:w, tags });
        }
      }));
      const errors = details.length;
      const skipped = details.filter(d=>d.skipped).length;
      return { sections, total, correct, errors, skipped, realTotal, realCorrect, nonTotal, nonCorrect,
               accuracy: total ? pct(correct,total)+'%' : 'N/A', details, time: mmss(state.elapsed) };
    }

    /* ============================ PANELS ============================ */
    function showLeft(id){ ['overviewPanel','gridPanel','resultsPanel'].forEach(p=>$(p).classList.toggle('active', p===id)); }
    function showControls(id){ ['activeControls','completeControls'].forEach(p=>$(p).classList.toggle('active', p===id)); $('setupControls').style.display = id ? 'none' : ''; }
    function setWorkflowBanner(title, text){ $('workflowBanner').innerHTML=`<strong>${title}</strong><span>${text}</span>`; }

    /* ============================ RENDER GRID ============================ */
    function renderSections(){
      const host = $('sectionsHost'); host.innerHTML='';
      const r = scoreData();
      const byId = Object.fromEntries(r.sections.map(s=>[s.id,s]));
      state.adminSecs.forEach(sec => {
        const sc = byId[sec.sectionId];
        const block = document.createElement('div');
        block.className='phonics-section';
        block.innerHTML = `<h3 class="sec-h">${esc(sec.sectionTitle)}<span class="sec-score">${sc.correct}/${sc.total}</span></h3><p class="sec-sub">Tap a word only if it was read incorrectly.</p>`;
        const grid = document.createElement('div');
        grid.className='word-grid';
        sec.words.forEach(w => {
          const m = state.marks[w.id];
          const wrong = m?.wrong;
          const b = document.createElement('button');
          b.type='button';
          b.className = 'word-tile' + (wrong ? ' incorrect' : '') + (m?.skipped ? ' skipped' : '');
          b.dataset.id = w.id;
          const respLine = wrong ? `<span class="wt-resp">${m.skipped ? 'skipped' : esc(m.response||'')}</span>` : '';
          b.innerHTML = `<span class="wt-word">${esc(w.word)}</span><span class="wt-tag ${w.type}">${w.type==='nonsense'?'nonsense':'real'}</span>${respLine}`;
          b.setAttribute('aria-pressed', !!wrong);
          b.setAttribute('aria-label', `${w.word}${wrong?', marked incorrect':''}`);
          b.addEventListener('click', () => handleWord(w.id));
          grid.appendChild(b);
        });
        block.appendChild(grid);
        host.appendChild(block);
      });
      updateLive();
    }
    function updateLive(){
      const r = scoreData();
      $('liveSectionPills').innerHTML = r.sections.map(s =>
        `<span class="live-pill"><span class="lp-l">${esc(shortName(s.title))}</span><b>${s.correct}/${s.total}</b></span>`).join('')
        + (state.timer ? `<span class="live-pill"><span class="lp-l">Time</span><b>${mmss(state.elapsed)}</b></span>` : '');
      $('errorCounter').textContent = `${r.errors} marked incorrect`;
      $('wordsChip').textContent = `${r.correct}/${r.total}`;
      $('errorsChip').textContent = `${r.errors}`;
      $('skippedChip').textContent = `${r.skipped}`;
      $('accChip').textContent = r.accuracy;
      $('liveMissed').innerHTML = r.details.length
        ? r.details.map(d=>`<span>${esc(d.word)}${d.skipped?' (skipped)':(d.response?` → ${esc(d.response)}`:'')}</span>`).join('')
        : '<span class="empty-small">Misread words appear here</span>';
    }
    const shortName = t => t.replace('Short Vowels in CVC Words','CVC short vowels')
      .replace('Consonant Blends with Short Vowels','Blends')
      .replace('Short Vowels with Digraphs and Trigraphs','Digraphs')
      .replace('R-Controlled Vowels','R-controlled')
      .replace('Long Vowel Spellings','Long vowels')
      .replace('Variant Vowels','Variant vowels')
      .replace('Low-Frequency Vowel and Consonant Spellings','Low-frequency');

    /* ============================ POPOVER (required) ============================ */
    function handleWord(id){
      closeWordPopover(false);
      const m = state.marks[id];
      if(m?.wrong){ delete state.marks[id]; renderSections(); return; } // undo
      state.marks[id] = { wrong:true, response:'', skipped:false, pending:true };
      renderSections();
      const tile = document.querySelector(`.word-tile[data-id="${id}"]`);
      if(tile) openWordPopover(tile, id);
    }
    function openWordPopover(tile, id){
      state.activeId = id;
      const w = WORD_BY_ID[id];
      $('responseTitle').textContent = `Marked wrong: ${w.word}`;
      $('responsePrompt').textContent = 'Type what the student read, or mark skipped.';
      $('responseInput').value = state.marks[id].response || '';
      updateSaveEnabled();
      const pop = $('responsePopover'); pop.classList.add('show');
      const rect = tile.getBoundingClientRect();
      const top = Math.min(window.innerHeight - pop.offsetHeight - 12, Math.max(12, rect.bottom + 8));
      const left = Math.min(window.innerWidth - pop.offsetWidth - 12, Math.max(12, rect.left));
      pop.style.top = `${top}px`; pop.style.left = `${left}px`;
      setTimeout(()=>$('responseInput').focus(),0);
    }
    function updateSaveEnabled(){ $('saveResponseBtn').disabled = !$('responseInput').value.trim(); }
    function closeWordPopover(explained){
      const id = state.activeId;
      if(!explained && id && state.marks[id]?.pending) delete state.marks[id]; // revert un-explained
      $('responsePopover').classList.remove('show'); state.activeId=null; renderSections();
    }
    function saveWordResponse(){
      const id = state.activeId; if(!id) return;
      const t = $('responseInput').value.trim(); if(!t) return;
      state.marks[id] = { wrong:true, response:t, skipped:false, pending:false };
      closeWordPopover(true);
    }
    function skipWord(){
      const id = state.activeId; if(!id) return;
      state.marks[id] = { wrong:true, response:'', skipped:true, pending:false };
      closeWordPopover(true);
    }

    /* ============================ TIMER ============================ */
    function updateTimerUI(){ $('timerDisplay').textContent = mmss(state.elapsed); }
    function tick(now){ if(!state.running) return; state.elapsed=(now-state.startAt)/1000; updateTimerUI(); updateLive(); state.raf=requestAnimationFrame(tick); }
    function startTimer(){ if(state.running||state.completed||!state.timer) return; state.running=true; state.startAt=performance.now()-state.elapsed*1000; $('startTimerBtn').disabled=true; $('stopTimerBtn').disabled=false; $('timeUpBanner').classList.remove('show'); $('timerHint').textContent='Timer running.'; state.raf=requestAnimationFrame(tick); }
    function stopTimer(){ if(!state.running) return; cancelAnimationFrame(state.raf); state.running=false; $('startTimerBtn').disabled=state.completed; $('stopTimerBtn').disabled=true; $('timerHint').textContent=state.completed?'Check complete.':'Timer paused.'; }
    function resetTimer(){
      cancelAnimationFrame(state.raf);
      Object.assign(state,{elapsed:0,running:false,completed:false,startAt:null});
      state.marks={}; closeWordPopover(false);
      $('startTimerBtn').disabled=false; $('stopTimerBtn').disabled=true; $('timeUpBanner').classList.remove('show'); $('timerHint').textContent='Ready.';
      setWorkflowBanner('Ready', bannerText());
      updateTimerUI(); renderSections();
    }
    const bannerText = () => state.timer ? 'Start the timer when the student begins, then tap any misread words.' : 'Have the student read each word and tap any they misread on the left.';

    /* ============================ FLOW ============================ */
    function beginAssessment(){
      collectSetup();
      Object.assign(state,{elapsed:0,running:false,completed:false,startAt:null});
      closeWordPopover(false);
      $('timerCard').hidden = !state.timer;
      renderSections(); showLeft('gridPanel'); showControls('activeControls');
      $('rightHeading').textContent='Check in Progress'; $('rightSubhead').textContent='';
      $('timerHint').textContent='Ready.'; $('startTimerBtn').disabled=false; $('stopTimerBtn').disabled=true;
      setWorkflowBanner('Ready', bannerText());
      $('gridFormTag').textContent = `${state.adminSecs.length} section${state.adminSecs.length===1?'':'s'}`;
      updateTimerUI();
    }
    function backToSetup(){ if(state.running) stopTimer(); showLeft('overviewPanel'); showControls(null); $('rightHeading').textContent='Assessment Details'; $('rightSubhead').textContent='Set up the assessment, then start when the student begins.'; }
    function finishedSheet(){ closeWordPopover(false); if(state.running) stopTimer(); state.completed=true; $('startTimerBtn').disabled=true; $('stopTimerBtn').disabled=true; $('timeUpBanner').classList.remove('show'); $('timerHint').textContent=`Finished in ${mmss(state.elapsed)}.`; setWorkflowBanner('Check complete', state.timer?`Finished in ${mmss(state.elapsed)}.`:'All sections scored.'); showResults(); }

    function showResults(){
      closeWordPopover(false); if(state.running) stopTimer(); state.completed=true;
      const r = scoreData();
      // complete card
      $('cWords').textContent = `${r.correct}/${r.total}`;
      const [oLab,oCls] = bandFor(r.correct, r.total);
      $('completeDetails').textContent = `${studentName()} · ${r.sections.length} section${r.sections.length===1?'':'s'}`;
      $('accuracyComplete').textContent = r.accuracy;
      $('errorsComplete').textContent = `${r.errors}`;
      $('timeChipComplete').hidden = !state.timer;
      $('fullTimeComplete').textContent = mmss(state.elapsed);
      // meta + overall banner
      const timed = state.timer ? ` · ${r.time}` : '';
      $('resultsMeta').textContent = `${studentName()} · ${formatDate($('assessmentDate').value)} · ${gradeText('Not selected')} · ${yearText('Not selected')}${timed}`;
      $('obScore').textContent = `${r.correct} / ${r.total}`;
      const ob = $('obBand'); ob.textContent = oLab; ob.className = 'band-pill ' + oCls;
      $('obSub').textContent = `${r.accuracy} overall · across ${r.sections.length} section${r.sections.length===1?'':'s'}`;
      // section rows
      $('sectionResults').innerHTML = r.sections.map(s => {
        const [lab,cls] = bandFor(s.correct, s.total);
        return `<div class="sec-result-row"><div class="srr-name">${esc(s.title)}<small>real ${s.realCorrect}/${s.realTotal} · nonsense ${s.nonCorrect}/${s.nonTotal}</small></div><div class="srr-score">${s.correct}<small> / ${s.total}</small></div><span class="band-pill ${cls}">${lab}</span></div>`;
      }).join('');
      // real vs nonsense
      $('realNonsenseMetrics').innerHTML =
        metric('Real words', `${r.realCorrect} / ${r.realTotal}${r.realTotal?` · ${pct(r.realCorrect,r.realTotal)}%`:''}`) +
        metric('Nonsense words', `${r.nonCorrect} / ${r.nonTotal}${r.nonTotal?` · ${pct(r.nonCorrect,r.nonTotal)}%`:''}`);
      // misread list
      $('missedWords').innerHTML = r.details.length
        ? r.details.map(d=>`<li>${esc(d.word)}${d.skipped?' (skipped)':(d.response?` → ${esc(d.response)}`:'')}</li>`).join('')
        : '<li class="empty">No words marked incorrect</li>';
      // pattern notes
      $('patternNotes').innerHTML = renderPatternNotes(r.details);
      showLeft('resultsPanel'); showControls('completeControls'); $('rightHeading').textContent='Check Complete'; $('rightSubhead').textContent='';
    }
    function bucketPatterns(details){
      const buckets = {};
      details.forEach(d => d.tags.forEach(tag => {
        (buckets[tag] = buckets[tag] || []).push({ word:d.word, response:d.response, focus:focusFor(d.item, tag) });
      }));
      return buckets;
    }
    function renderPatternNotes(details){
      if(!details.length) return '<p class="empty-small">No misread words to analyze.</p>';
      const buckets = bucketPatterns(details);
      const keys = Object.keys(buckets).sort((a,b)=>(PAT[a]?.order||99)-(PAT[b]?.order||99));
      return keys.map(tag => {
        const ex = buckets[tag].slice(0,8).map(e => `<span class="pattern-chip">${esc(e.word)}${e.response?` → ${esc(e.response)}`:''}${e.focus?` · ${esc(e.focus)}`:''}</span>`).join('');
        const extra = buckets[tag].length>8 ? `<span class="pattern-chip">+${buckets[tag].length-8} more</span>` : '';
        return `<div class="pattern-card"><h4>${PAT[tag].label} · ${buckets[tag].length}</h4><div class="pattern-examples">${ex}${extra}</div><p>${PAT[tag].guide}</p></div>`;
      }).join('');
    }
    function patternPrintRows(details){
      if(!details.length) return '<p>No misread words to analyze.</p>';
      const buckets = bucketPatterns(details);
      const keys = Object.keys(buckets).sort((a,b)=>(PAT[a]?.order||99)-(PAT[b]?.order||99));
      return `<div class="print-pattern-list">${keys.map(tag => {
        const ex = buckets[tag].map(e => `${e.word}${e.response?` → ${e.response}`:''}${e.focus?` (${e.focus})`:''}`).join(', ');
        return `<div class="print-pattern"><h3>${PAT[tag].label} · ${buckets[tag].length}</h3><p class="examples">Examples: ${esc(ex)}</p><p>${esc(PAT[tag].guide)}</p></div>`;
      }).join('')}</div>`;
    }
    function editScoring(){ showLeft('gridPanel'); showControls('activeControls'); $('rightHeading').textContent='Edit Scoring'; $('rightSubhead').textContent=''; }
    function newAssessment(){ if(state.running) stopTimer(); if($('teacherNotes')) $('teacherNotes').value=''; state.marks={}; showLeft('overviewPanel'); showControls(null); $('setupControls').style.display=''; $('rightHeading').textContent='Assessment Details'; $('rightSubhead').textContent='Set up the assessment, then start when the student begins.'; }

    /* ============================ PRINT ============================ */
    function studentPrintHTML(){
      collectSetup();
      const logo = document.querySelector('.brand-mark')?.src || '';
      const secs = state.adminSecs.map(sec => `
        <div class="ps-section">
          <h2>${esc(sec.sectionTitle)}</h2>
          <div class="ps-words">${sec.words.map(w=>`<span class="ps-word">${esc(w.word)}</span>`).join('')}</div>
        </div>`).join('');
      return `<div class="print-student">
        <div class="print-brand"><div class="print-brand-left"><img class="print-logo" src="${logo}" alt=""><div><div class="print-brand-name">Literacy Arcade</div><div class="print-tool-name">Phonics Knowledge Check</div></div></div><div class="print-tool-name">literacyarcade.com</div></div>
        <h1>Phonics Knowledge Check Student Sheet</h1>
        <p class="print-subtitle">${state.adminSecs.length} section${state.adminSecs.length===1?'':'s'} · read each word aloud</p>
        <p class="student-directions">Read each word out loud, going across each row. Some are made-up words — sound them out.</p>
        ${secs}
        <div class="print-footer"><span>Literacy Arcade • literacyarcade.com</span></div>
      </div>`;
    }
    function reportPrintHTML(){
      const r = scoreData(), name = studentName(), logo = document.querySelector('.brand-mark')?.src || '';
      const [oLab] = bandFor(r.correct, r.total);
      const sectionRows = r.sections.map(s => {
        const [lab] = bandFor(s.correct, s.total);
        return `<tr><td>${esc(s.title)}</td><td>${s.correct} / ${s.total}</td><td>${pct(s.correct,s.total)}%</td><td>${lab}</td><td>r ${s.realCorrect}/${s.realTotal} · n ${s.nonCorrect}/${s.nonTotal}</td></tr>`;
      }).join('');
      const missed = r.details.length ? r.details.map(d=>`<span class="print-chip">${esc(d.word)}${d.skipped?' (skipped)':(d.response?` → ${esc(d.response)}`:'')}</span>`).join('') : 'None';
      const notes = esc($('teacherNotes').value.trim() || 'No teacher notes provided.').replace(/\n/g,'<br>');
      const timeRow = state.timer ? `<tr><td>Completion time</td><td>${r.time}</td></tr>` : '';
      return `<div class="print-report">
        <div class="print-brand"><div class="print-brand-left"><img class="print-logo" src="${logo}" alt=""><div><div class="print-brand-name">Literacy Arcade</div><div class="print-tool-name">Phonics Knowledge Check</div></div></div><div class="print-tool-name">literacyarcade.com</div></div>
        <h1>Phonics Knowledge Check Report</h1>
        <p class="print-subtitle">Decoding by phonics pattern · real and made-up words · instructional screening, not a diagnosis</p>
        <div class="report-meta"><div><b>Student</b>${esc(name)}</div><div><b>Date</b>${esc(formatDate($('assessmentDate').value))}</div><div><b>Grade</b>${esc(gradeText())}</div><div><b>Time of Year</b>${esc(yearText())}</div><div><b>Overall</b>${r.correct} / ${r.total} (${r.accuracy})</div><div><b>Level</b>${oLab}</div></div>
        <div class="print-two-col">
          <div class="print-card"><h2>Summary</h2><table class="print-table"><tr><td>Total words correct</td><td>${r.correct} / ${r.total}</td></tr><tr><td>Overall accuracy</td><td>${r.accuracy}</td></tr><tr><td>Real words</td><td>${r.realCorrect} / ${r.realTotal}</td></tr><tr><td>Nonsense words</td><td>${r.nonCorrect} / ${r.nonTotal}</td></tr><tr><td>Skipped / no attempt</td><td>${r.skipped}</td></tr>${timeRow}</table></div>
          <div class="print-card"><h2>Misread Words</h2><p class="print-missed-line">${missed}</p></div>
        </div>
        <div class="print-section print-card"><h2>Accuracy by Section</h2><table class="print-table print-section-table"><thead><tr><th>Section</th><th>Score</th><th>%</th><th>Level</th><th>Real · Nonsense</th></tr></thead><tbody>${sectionRows}</tbody></table><p class="print-note">Strong control = 85%+ · Developing = 60–84% · Needs support = below 60%. Instructional guidance, not a normed benchmark.</p></div>
        <div class="print-section print-card"><h2>Instructional Focus · Error Patterns</h2><p class="print-intro">These notes group the misread words by what changed. Wording is kept tentative ("possible focus") on purpose — this is an instructional screen, not a diagnosis.</p>${patternPrintRows(r.details)}<p class="print-note">A single word can appear under more than one note. Use the patterns to guide instruction.</p></div>
        <div class="print-section print-card"><h2>Teacher Notes</h2><p class="teacher-note-print">${notes}</p></div>
        <div class="print-note">This check screens decoding by phonics pattern using real and made-up words. It is meant to guide instruction and is not a diagnosis or a timed fluency measure. Consider stopping or shortening a section if it was clearly too difficult for the student.</div>
        <div class="print-footer"><span>Literacy Arcade • literacyarcade.com</span><span>Generated by the Phonics Knowledge Check</span></div>
      </div>`;
    }
    function printContent(kind){
      const student=$('studentPrint'), report=$('reportPrint'); student.innerHTML=''; report.innerHTML='';
      const target = kind==='student' ? student : report;
      target.innerHTML = kind==='student' ? studentPrintHTML() : reportPrintHTML();
      document.body.classList.remove('printing-student','printing-report');
      document.body.classList.add('printing', kind==='student'?'printing-student':'printing-report');
      const finishPrint=()=>{ window.print(); setTimeout(()=>document.body.classList.remove('printing','printing-student','printing-report'),400); };
      const logoImg = target.querySelector('img.print-logo');
      if(logoImg && typeof logoImg.decode==='function'){ logoImg.decode().then(finishPrint).catch(finishPrint); }
      else if(logoImg && !logoImg.complete){ logoImg.addEventListener('load',finishPrint,{once:true}); logoImg.addEventListener('error',finishPrint,{once:true}); }
      else { finishPrint(); }
    }

    /* ============================ WIRING ============================ */
    renderSectionToggles();
    $('printSheetBtn').addEventListener('click', ()=>printContent('student'));
    $('startAssessmentBtn').addEventListener('click', beginAssessment);
    $('startTimerBtn').addEventListener('click', startTimer);
    $('stopTimerBtn').addEventListener('click', stopTimer);
    $('resetTimerBtn').addEventListener('click', resetTimer);
    $('finishedSheetBtn').addEventListener('click', finishedSheet);
    $('backSetupBtn').addEventListener('click', backToSetup);
    $('printReportBtn').addEventListener('click', ()=>printContent('report'));
    $('editScoringCompleteBtn').addEventListener('click', editScoring);
    $('newAssessmentBtn').addEventListener('click', newAssessment);
    $('responseInput').addEventListener('input', updateSaveEnabled);
    $('responseInput').addEventListener('keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); saveWordResponse(); } });
    $('saveResponseBtn').addEventListener('click', saveWordResponse);
    $('skipResponseBtn').addEventListener('click', ()=>closeWordPopover(false)); // Cancel → revert
    $('quickResponseButtons').addEventListener('click', e=>{ const btn=e.target.closest('button'); if(btn && btn.dataset.response==='__SKIP__') skipWord(); });
    document.addEventListener('keydown', e=>{ if(e.key==='Escape' && $('responsePopover').classList.contains('show')) closeWordPopover(false); });
    document.addEventListener('click', e=>{ if($('responsePopover').classList.contains('show') && !$('responsePopover').contains(e.target) && !e.target.closest('.word-tile')) closeWordPopover(false); }, true);
    $('clearNotesBtn')?.addEventListener('click', ()=>{ $('teacherNotes').value=''; });
  })();
  </script>
